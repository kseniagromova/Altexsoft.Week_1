﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;
using System.IO;

namespace Task3_2
{
    class Pow
    {
        static void Main(string[] args)
        {
            double num, square;
            Random rnd = new Random();
            StreamWriter str = new StreamWriter("square.txt");
            for (int i = 0; i <= 10; i++)
            {
                str.WriteLine(rnd.Next(10));
            }
            str.WriteLine();
            str.Close();
            StreamReader read = new StreamReader("square.txt");
            for (int i = 0; i <= 10; i++)
            {
                num = double.Parse(read.ReadLine());
                square = Math.Pow(num, 2);
                Console.WriteLine("File number: " + num + " Square: " + square);
            }
            Console.ReadKey();
           
        }
    }
}
