﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Task3_1
{
    class Sum
    {
        static void Main(string[] args)
        {
            var rx = new Regex(@"[-+]?\d+\.?\d+([eE][-+]?\d+)?", RegexOptions.Compiled);
            StreamReader reader = File.OpenText("sumfile.txt");
            string contents = reader.ReadToEnd();
            Console.WriteLine(contents);
            var sum = rx.Matches(contents).Cast<Match>().Select(
                    num => float.Parse(
                            num.Value,
                            NumberStyles.Float, CultureInfo.InvariantCulture.NumberFormat
                            )).Sum();
            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
