﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Task3_3
{
    class Directories
    {
        static void Main(string[] args)
        {
         string[] fullfilesPath =Directory.GetFiles(@"D:\MyDocuments\", "*.*",SearchOption.AllDirectories);
            Console.WriteLine(fullfilesPath);
        }
    }
}
