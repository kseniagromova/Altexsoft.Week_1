﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2_4
{
    class Array_2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input sizes: ");
            var size = new int[int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine())];
            Random rdm = new Random();
            for (int i = 0; i < size.GetLength(0); i++)
                for (int j = 0; j < size.GetLength(1); j++)
                    Console.Write("{0,4}" + ((j == size.GetLength(1) - 1) ? "\n" : " "), size[i, j] = rdm.Next(-501, 501));
            var sum = Enumerable.Range(0, size.GetLength(1)).Select(x => Enumerable.Range(0, size.GetLength(0)).Select(e => size[e, x]).ToArray()).OrderByDescending(x => x.Sum()).ToArray();
            Console.WriteLine("New array:");
            for (int i = 0; i < size.GetLength(0); i++)
                for (int j = 0; j < size.GetLength(1); j++)
                    Console.Write("{0,4}" + ((j == size.GetLength(1) - 1) ? "\n" : " "), size[i, j] = sum[j][i]);
            Console.ReadKey();
        }
    }
}
