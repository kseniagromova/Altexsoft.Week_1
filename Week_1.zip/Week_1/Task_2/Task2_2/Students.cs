﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2_2
{
    class Students
    {
        struct Student : IComparable<Student>
        {
            public string firstName;
            public string lastName;
            public int age;
            int result;
            public int CompareTo(Student other)
            {
                result = this.firstName.CompareTo(other.firstName);
                return result;
            }

            public void Info()
            {
                Console.WriteLine("Lastname: {0} Name:  {1}  Age:  {2}", lastName, firstName, age);
            }
        }
        static void Main(string[] args)
        {
            Student[] student = new Student[4];
            student[0].firstName = "Kate";
            student[0].lastName = "Klermont";
            student[0].age = 18;

            student[1].firstName = "Mike";
            student[1].lastName = "Cole";
            student[1].age = 21;

            student[2].firstName = "Sonya";
            student[2].lastName = "Billy";
            student[2].age = 20;

            student[3].firstName = "Damy";
            student[3].lastName = "Cruel";
            student[3].age = 19;

            Array.Sort(student);

            foreach (Student s in student)
            {
                s.Info();
            }

            Console.ReadKey();

        }
    }
}
