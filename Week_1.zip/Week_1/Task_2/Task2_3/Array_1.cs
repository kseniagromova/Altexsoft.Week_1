﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2_3
{
    class Array_1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input the size of array: ");
            int size = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[size];
            Random rdm = new Random();
            for (int i = 0; i < size; i++)
            {
                array[i] = rdm.Next(-501, 501);
                Array.Sort(array);
            }

            foreach (int i in array)
            {
                Console.Write(i + " ");
            }
            Console.ReadKey();
        }
    }
}
