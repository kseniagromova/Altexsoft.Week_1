﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4_2
{
    class Student_info2
    {
        class Student : IComparable
        {
            protected string FullName;
            protected int Group;
            protected int Result1;
            protected int Result2;
            protected int Result3;

            public Student(string _fullName, int _group, int _result1, int _result2, int _result3)
            {
                FullName = _fullName;
                Group = _group;
                Result1 = _result1;
                Result2 = _result2;
                Result3 = _result3;
            }

            public int CompareTo(object success)
            {
                return Group.CompareTo(((Student)success).Group);
            }

            public override string ToString()
            {
                return String.Format("{0}; {1}; {2}; {3}; {4}", FullName, Group, Result1, Result2, Result3);
            }

        }
        static void Main(string[] args)
        {
            Student[] students = new Student[5];
            string name;
            int group, result1, result2, result3;
            //data about students
            for (int i = 0; i < 5; i++)
            {
                Console.Write("{0}\nName: ", i + 1);
                name = Console.ReadLine();
                Console.Write("Group: ");
                group = Convert.ToInt32(Console.ReadLine());
                Console.Write("Mark 1: ");
                result1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Mark 2: ");
                result2 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Mark 3: ");
                result3 = Convert.ToInt32(Console.ReadLine());

                //check of marks
                if (result1 == 5 && result2 == 5 && result3 == 5)
                {
                    Student student = new Student(name, group, result1, result2, result3);
                    students[i] = student;
                }
                else
                {
                    Console.WriteLine("Marks aren't excellent!");
                }
            }
            Array.Sort(students);
            foreach (Student student in students) Console.WriteLine(student);
            Console.ReadKey();
        }
    }
}
