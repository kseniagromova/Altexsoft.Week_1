﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4_4
{
    class Auto
    
    {
        class Car : IComparable
        {
            protected string Brand;
            protected int Number;
            protected string Lastname;
            protected int Year;
            protected double Run;

            public Car(string _brand, int _number, string _lastname,int _year,double _run)
            {
                Brand = _brand;
                Number = _number;
                Lastname = _lastname;
                Year=_year;
                Run=_run;
            }

            //comparison cars according to run
            public int CompareTo(object run)
            {
                return Run.CompareTo(((Car)run).Run);
            }

            public override string ToString()
            {
                return String.Format("Car: {0}; Number: {1}; Car owner: {2}; Purchase year: {3}; Run: {4}",Brand, Number, Lastname,Year,Run);
            }

        }

        static void Main(string[] args)
        {
            Car[] cars = new Car[5];
            string name,brand;
            int number,year;
            double run;

            //data about car
            for (int i = 0; i < 5; i++)
            {
                Console.Write("{0}\nCar Brand: ", i + 1);
                brand = Console.ReadLine();
                Console.Write("Car number: ");
                number = Convert.ToInt32(Console.ReadLine());
                Console.Write("Owner Name: ");
                name = Console.ReadLine();
                Console.Write("Purchase year: ");
                year = Convert.ToInt32(Console.ReadLine());
                Console.Write("Run: ");
                run = Convert.ToDouble(Console.ReadLine());

                //check car year
                if (year <=2000)
                {
                    Car car = new Car(brand, number, name, year,run);
                    cars[i] = car;
                }
                else
                {
                    Console.WriteLine("The year of this car is more than 2000");
                }
            }
            Array.Sort(cars);
            foreach (Car car in cars) Console.WriteLine(car);
            Console.ReadKey();

        }
    }
}
