﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4_3
{
    class Luggage
    {
        class Passenger : IComparable
        {
            protected string FullName;
            protected int Quantity;
            protected double Weight;

            public Passenger(string _fullName, int _quantity, double _weight)
            {
                FullName = _fullName;
                Quantity = _quantity;
                Weight = _weight;
            }

            //comparison of passenger's luggage according to quantity
            public int CompareTo(object number)
            {
                return Quantity.CompareTo(((Passenger)number).Quantity);
            }

            public override string ToString()
            {
                return String.Format("{0}; Quantity of luggage: {1}; Weight of luggage: {2}", FullName, Quantity, Weight);
            }

        }
        static void Main(string[] args)
        {
            Passenger[] passengers = new Passenger [5];
            string name;
            int quantity;
            double weight;

            //data about passenger's luggage
            for (int i = 0; i < 5; i++)
            {
                Console.Write("{0}\nName: ", i + 1);
                name = Console.ReadLine();
                Console.Write("Quantity of luggage: ");
                quantity = Convert.ToInt32(Console.ReadLine());
                Console.Write("Weight: ");
                weight = Convert.ToDouble(Console.ReadLine());
                
                //check luggage weight
                if (weight > 5.0)
                {
                    Passenger passenger = new Passenger(name, quantity, weight);
                    passengers[i] = passenger;
                }
                else
                {
                    Console.WriteLine("This passenger has luggage less than 5");
                }  
            }
            Array.Sort(passengers);
            foreach (Passenger passenger in passengers) Console.WriteLine(passenger);
            Console.ReadKey();
        }
    }
}
