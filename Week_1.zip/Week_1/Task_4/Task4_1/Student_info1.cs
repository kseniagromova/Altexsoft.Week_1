﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4_1
{
    class Student_info1
    {
        class Student : IComparable<Student>
        {

            protected string Name;
            protected int YearOfBirth;
            protected string HomeAddress;
            protected string School;

            public Student(string name, int yearOfBirth, string homeAddress, string school)
            {
                Name = name;
                YearOfBirth = yearOfBirth;
                HomeAddress = homeAddress;
                School = school;

            }

            public int CompareTo(Student obj)
            {
                return YearOfBirth.CompareTo(obj.YearOfBirth);
            }

            public override string ToString()
            {
                return string.Format("{0}; {1}; {2}; {3}", Name, YearOfBirth, HomeAddress, School);
            }

        }


        static void Main(string[] args)
        {
            Student[] students = new Student[5];// array of students
            string name, home, school;
            int year;

            for (int i = 0; i < 5; i++)
            {

                Console.Write("{0}\nName: ", i + 1);

                name = Console.ReadLine();

                Console.Write("Year of birthday: ");

                year = Convert.ToInt32(Console.ReadLine());

                Console.Write("Home address: ");

                home = Console.ReadLine();

                Console.Write("School:");

                school = Console.ReadLine();

                Student student = new Student(name, year, home, school);

                students[i] = student;

            }

            Array.Sort(students); // Sort
            foreach (Student student in students) Console.WriteLine(student); // Data output

            Console.ReadKey();
        }
    }
}
